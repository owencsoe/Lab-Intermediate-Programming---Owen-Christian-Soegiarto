print("   +")
print(" +   +")
print("+-----+")
print("| .-. |")
print("| | | |")
print("+-+-+-+")


johnapple = int(input("How many apples does John have?"))   
maryapple = int(input("How many apples does Mary have?"))       
daveapple = int(input("How many apples does Dave have?"))
print ("In total they all have", johnapple+maryapple+daveapple, "apples")